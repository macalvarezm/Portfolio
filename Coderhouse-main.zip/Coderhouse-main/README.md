# CoderHouse

## [Data Analytics](https://github.com/macalvarezm/Coderhouse/tree/main/Data%20Analytics)
Análisis de los incendios forestales en Argentina, limpieza de datos usando Excel y Power Bi.

## [Data Science](https://github.com/macalvarezm/Coderhouse/tree/main/Data%20Science)
### [Desafíos](https://github.com/macalvarezm/Coderhouse/tree/main/Data%20Science/Desaf%C3%ADos) 
Desafíos realizados durante la cursada, usando las librerías Pandas, Numpy, Seaborn y Matplotlib.
